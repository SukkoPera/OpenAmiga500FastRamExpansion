******************************************************************************
*           BSDL files for ATF1502AS/ASL/ASV in all package types            *
******************************************************************************

1502AS_A44.bsd  - BSDL file for ATF1502AS/ASL in 44-pin TQFP package type.

1502AS_J44.bsd  - BSDL file for ATF1502AS/ASL in 44-pin PLCC package type.

1502ASV_A44.bsd - BSDL file for ATF1502ASV in 44-pin TQFP package type.

1502ASV_J44.bsd - BSDL file for ATF1502ASV in 44-pin PLCC package type.

